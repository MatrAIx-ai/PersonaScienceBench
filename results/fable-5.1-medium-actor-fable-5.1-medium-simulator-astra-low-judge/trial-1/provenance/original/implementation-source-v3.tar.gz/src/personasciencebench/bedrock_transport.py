"""Direct AWS clients for the qualified Fable/Astra campaign. No proxy server."""
import copy
import json
import os
from pathlib import Path
import random
import time
from urllib.error import HTTPError
from urllib.request import HTTPRedirectHandler, Request, build_opener

import boto3
from botocore.auth import SigV4Auth
from botocore.awsrequest import AWSRequest
from botocore.config import Config
from botocore.exceptions import ClientError

from personasciencebench.openai_transport import ResponsesTransport

REGION = "us-west-2"
FABLE = "us.anthropic.claude-fable-5-1"
ASTRA = "us.openai.gpt-6-astra"
EFFORTS = {FABLE: "medium", ASTRA: "low"}
TRANSIENT = {429, 500, 502, 503, 504}


def fatal_error(status, code):
    path = os.environ.get("PSB_FATAL_API_FILE")
    if path and status in {400, 401, 403, 404}:
        Path(path).write_text(json.dumps({"provider": "bedrock", "status": status, "code": code}))


def check_fatal():
    path = os.environ.get("PSB_FATAL_API_FILE")
    if path and Path(path).exists():
        raise RuntimeError("Campaign stopped; inspect fatal_api.json before resuming")


def validate_model(model, effort):
    if model not in EFFORTS or effort != EFFORTS[model]:
        raise ValueError("Bedrock model/effort is outside the qualified Fable-medium/Astra-low campaign")


def preflight(models, timeout=45):
    client = boto3.Session().client("bedrock", region_name=REGION,
        config=Config(connect_timeout=15, read_timeout=timeout, retries={"total_max_attempts": 1}))
    profiles = {}
    selected = {}
    for role, spec in models.items():
        model = spec["model"]
        validate_model(model, spec.get("reasoning_effort"))
        expected = ASTRA if role == "judge" else FABLE
        if model != expected:
            raise ValueError("Actor/researcher must be Fable; judge must be Astra")
        if model not in profiles:
            profile = client.get_inference_profile(inferenceProfileIdentifier=model)
            if profile["status"] != "ACTIVE" or profile["inferenceProfileId"] != model:
                raise ValueError("Exact Bedrock profile is not active")
            profiles[model] = {k: profile[k] for k in ("inferenceProfileId", "status", "models")}
        selected[role] = {
            "id": model, "provider": "bedrock", "region": REGION,
            "reasoning_effort": spec["reasoning_effort"], "profile": profiles[model],
            "pricing": None, "pricing_status": "unverified; token accounting only",
            "supported_parameters": ["max_tokens", "tools", "reasoning", "structured_outputs"],
            "decision_format": "native_json_schema" if model == FABLE else "responses",
        }
    return selected


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class BedrockResponsesTransport(ResponsesTransport):
    provider = "bedrock"

    def __init__(self, timeout=600):
        super().__init__(timeout)
        self.session = boto3.Session()
        self.opener = build_opener(NoRedirect())

    def _send(self, request):
        validate_model(request["model"], request.get("reasoning", {}).get("effort"))
        check_fatal()
        data = json.dumps(request).encode()
        url = f"https://bedrock-runtime.{REGION}.amazonaws.com/openai/v1/responses"
        for retry in range(4):
            signed = AWSRequest(method="POST", url=url, data=data, headers={"Content-Type": "application/json"})
            SigV4Auth(self.session.get_credentials().get_frozen_credentials(), "bedrock", REGION).add_auth(signed)
            try:
                with self.opener.open(Request(url, data=data, headers=dict(signed.headers),
                                             method="POST"), timeout=self.timeout) as response:
                    raw = json.load(response)
                if raw.get("model") != request["model"]:
                    raise RuntimeError("Bedrock returned a different Astra model")
                return raw, retry
            except HTTPError as error:
                status = error.code
                error.close()
                if status not in TRANSIENT or retry == 3:
                    fatal_error(status, "responses_http_error")
                    raise RuntimeError(f"Bedrock Responses HTTP {status}") from None
                time.sleep(2 ** retry + random.random())
        raise AssertionError("unreachable")


def text_parts(value):
    if value is None or value == "":
        return []
    if isinstance(value, str):
        return [{"type": "text", "text": value}]
    if isinstance(value, list) and all(p.get("type") == "text" for p in value):
        return copy.deepcopy(value)
    raise ValueError("Unsupported non-text content at the Bedrock boundary")


class AnthropicTransport:
    def __init__(self, timeout=600):
        self.client = boto3.Session().client("bedrock-runtime", region_name=REGION,
            config=Config(connect_timeout=15, read_timeout=timeout, retries={"total_max_attempts": 1}))
        self.history = {}

    def request(self, payload):
        validate_model(payload["model"], payload.get("reasoning", {}).get("effort"))
        allowed = {"model", "messages", "max_tokens", "provider", "reasoning",
                   "tools", "tool_choice", "response_format", "stream"}
        if set(payload) - allowed:
            raise ValueError("Unsupported Fable generation settings: " + ", ".join(sorted(set(payload) - allowed)))
        system, messages = [], []
        for message in payload["messages"]:
            role = message["role"]
            if role == "system":
                if messages:
                    raise ValueError("System messages must precede conversation content")
                system.extend(text_parts(message.get("content")))
                continue
            calls = message.get("tool_calls") or []
            if role == "tool":
                role = "user"
                parts = [{"type": "tool_result", "tool_use_id": message["tool_call_id"],
                          "content": message.get("content") or ""}]
            elif calls:
                key = tuple(c["id"] for c in calls)
                if key not in self.history:
                    raise ValueError("Native signed tool history is missing; refusing lossy replay")
                parts = copy.deepcopy(self.history[key])
                native = {p["id"]: p for p in parts if p["type"] == "tool_use"}
                for call in calls:
                    item = native[call["id"]]
                    if item["name"] != call["function"]["name"] or item["input"] != json.loads(call["function"]["arguments"]):
                        raise ValueError("Tool history was modified by the actor SDK")
            else:
                parts = text_parts(message.get("content"))
            if role not in {"user", "assistant"}:
                raise ValueError("Unsupported message role")
            if not parts:
                continue
            if messages and messages[-1]["role"] == role:
                messages[-1]["content"].extend(parts)
            else:
                messages.append({"role": role, "content": parts})
        body = {"anthropic_version": "bedrock-2023-05-31", "messages": messages,
                "max_tokens": payload["max_tokens"], "thinking": {"type": "adaptive"},
                "output_config": {"effort": "medium"}}
        if system:
            body["system"] = system
        if payload.get("tools"):
            body["tools"] = [{"name": t["function"]["name"],
                              "description": t["function"].get("description", ""),
                              "input_schema": t["function"]["parameters"]}
                             for t in payload["tools"]]
        choice = payload.get("tool_choice")
        if choice not in (None, "auto"):
            raise ValueError("Fable does not support forced tool calls; use native decision JSON schema")
        fmt = payload.get("response_format")
        if fmt:
            if fmt["type"] != "json_schema":
                raise ValueError("Fable requires an explicit JSON schema")
            body["output_config"]["format"] = {"type": "json_schema", "schema": fmt["json_schema"]["schema"]}
        return body

    def complete(self, payload):
        body = self.request(payload)
        check_fatal()
        for retry in range(4):
            try:
                wire = self.client.invoke_model(modelId=payload["model"], body=json.dumps(body).encode(),
                    contentType="application/json", accept="application/json")
                try:
                    raw = json.loads(wire["body"].read())
                finally:
                    wire["body"].close()
                break
            except ClientError as error:
                status = error.response.get("ResponseMetadata", {}).get("HTTPStatusCode")
                code = error.response.get("Error", {}).get("Code", "unknown")
                if status not in TRANSIENT or retry == 3:
                    fatal_error(status, code)
                    raise RuntimeError(f"Bedrock InvokeModel HTTP {status}: {code}") from None
                time.sleep(2 ** retry + random.random())
        if raw.get("model") != "claude-fable-5-1":
            raise RuntimeError("Bedrock returned a different Fable model")
        parts = raw.get("content", [])
        calls = [{"id": p["id"], "type": "function", "function": {
            "name": p["name"], "arguments": json.dumps(p["input"], ensure_ascii=False)}}
            for p in parts if p["type"] == "tool_use"]
        content = "".join(p["text"] for p in parts if p["type"] == "text")
        if calls:
            self.history[tuple(c["id"] for c in calls)] = copy.deepcopy(parts)
        usage = raw.get("usage", {})
        prompt = sum(usage.get(k, 0) for k in ("input_tokens", "cache_creation_input_tokens", "cache_read_input_tokens"))
        output = usage.get("output_tokens")
        if type(prompt) is not int or type(output) is not int:
            raise RuntimeError("Bedrock omitted token usage")
        message = {"role": "assistant", "content": content or None}
        if calls:
            message["tool_calls"] = calls
        stop = raw.get("stop_reason")
        finish = {"end_turn": "stop", "tool_use": "tool_calls", "max_tokens": "length"}.get(stop, "error")
        return {"id": raw["id"], "object": "chat.completion", "model": raw["model"], "provider": "bedrock",
                "choices": [{"index": 0, "finish_reason": finish, "message": message}],
                "usage": {"prompt_tokens": prompt, "completion_tokens": output,
                          "total_tokens": prompt + output, "native_usage": usage, "cost": None},
                "_native_request": body, "_native_response": raw, "_rate_limit_retries": retry}


def transport(model, timeout=600):
    if model == FABLE:
        return AnthropicTransport(timeout)
    if model == ASTRA:
        return BedrockResponsesTransport(timeout)
    raise ValueError("Unqualified Bedrock model")
