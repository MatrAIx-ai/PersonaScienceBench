#!/usr/bin/env python3
"""Wrap bwrap with a command policy and a kernel denial of bind/listen.

Only the sandboxed command receives the filter. This is not a server and does
not execute actor commands on the host. Libseccomp emits the native BPF filter.
"""
import ctypes
import ctypes.util
import os
from pathlib import Path
import sys
import tempfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from personasciencebench.machine_policy import validate_command


def filter_file():
    library = ctypes.util.find_library("seccomp")
    if not library:
        raise RuntimeError("libseccomp is required; no execution fallback")
    lib = ctypes.CDLL(library, use_errno=True)
    lib.seccomp_init.argtypes = [ctypes.c_uint32]
    lib.seccomp_init.restype = ctypes.c_void_p
    lib.seccomp_syscall_resolve_name.argtypes = [ctypes.c_char_p]
    lib.seccomp_syscall_resolve_name.restype = ctypes.c_int
    lib.seccomp_rule_add.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_int, ctypes.c_uint]
    lib.seccomp_rule_add.restype = ctypes.c_int
    lib.seccomp_export_bpf.argtypes = [ctypes.c_void_p, ctypes.c_int]
    lib.seccomp_export_bpf.restype = ctypes.c_int
    lib.seccomp_release.argtypes = [ctypes.c_void_p]
    ctx = lib.seccomp_init(0x7FFF0000)  # SCMP_ACT_ALLOW
    if not ctx:
        raise RuntimeError("Cannot initialize seccomp")
    output = tempfile.TemporaryFile()
    try:
        for name in (b"bind", b"listen"):
            syscall = lib.seccomp_syscall_resolve_name(name)
            if syscall < 0 or lib.seccomp_rule_add(ctx, 0x00050001, syscall, 0) != 0:
                raise RuntimeError("Cannot install listener prohibition")
        if lib.seccomp_export_bpf(ctx, output.fileno()) != 0:
            raise RuntimeError("Cannot export seccomp filter")
        output.seek(0)
        return output
    except BaseException:
        output.close()
        raise
    finally:
        lib.seccomp_release(ctx)


def main():
    args = sys.argv[1:]
    command_index = max((i for i, value in enumerate(args) if value == "/bin/bash"), default=-1)
    if command_index < 0 or args[-2] != "-c":
        raise ValueError("Expected the benchmark's fixed Bash command boundary")
    validate_command(args[-1])
    masks = []
    for directory in ("/usr/bin", "/bin"):
        for name in ("node", "nodejs", "npm", "npx", "yarn", "pnpm", "bun", "deno", "js", "qjs", "d8"):
            target = Path(directory) / name
            if target.exists():
                masks.extend(("--ro-bind", "/dev/null", str(target.resolve())))
    guard = filter_file()
    os.set_inheritable(guard.fileno(), True)
    command = ["/usr/bin/bwrap", *args[:command_index], *masks,
               "--seccomp", str(guard.fileno()), *args[command_index:]]
    os.execv(command[0], command)


if __name__ == "__main__":
    main()
