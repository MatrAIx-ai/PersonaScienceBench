"""Robert's standing execution restrictions, disclosed in executable tool help."""
import os
import re

POLICY = (
    "Machine policy: use Python, shell and scientific tools. Do not write, modify, "
    "install or execute JavaScript/TypeScript or Node/npm/Bun/Deno tools. "
    "Do not create or start any server or listener, including localhost. "
    "Do not access the RLScience cluster."
)


def execution_note():
    return " " + POLICY if os.environ.get("PSB_MACHINE_POLICY") == "robert-20261003" else ""


def validate_command(command):
    prohibited = (
        r"\b(?:nodejs|npm|npx|yarn|pnpm|bun|deno|javascript|typescript|"
        r"quickjs|js2py|py_mini_racer|qjs|uvicorn|gunicorn|http-server|"
        r"HTTPServer|TCPServer|UDPServer|serve_forever|rlscience)\b"
        r"|\.(?:mjs|cjs|js|jsx|ts|tsx)\b"
        r"|\bhttp\.server\b|\b(?:socket|socketserver)\b"
        r"|\b(?:flask|fastapi|starlette)\b"
        r"|(?:^|[;&|\n]\s*|[\"']|/usr/bin/|\bexec\s+)node\s"
    )
    if re.search(prohibited, command, re.IGNORECASE):
        raise ValueError("Command blocked by the disclosed machine execution policy")
