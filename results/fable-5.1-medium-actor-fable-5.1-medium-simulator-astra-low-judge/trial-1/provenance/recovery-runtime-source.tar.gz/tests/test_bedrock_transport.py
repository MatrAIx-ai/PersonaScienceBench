"""Offline provider-boundary and accounting checks; no sockets or live clients."""
import copy
import io
import json
from types import SimpleNamespace
from unittest.mock import patch

import pytest

from personasciencebench.bedrock_transport import AnthropicTransport, FABLE, ASTRA
from personasciencebench.inference import OpenRouterClient
from personasciencebench.machine_policy import validate_command
from expbench.budget import Budget, Ledger
from expbench.gateway import Gateway, ModelError
from expbench.schema import ModelSettings


def payload(messages=None):
    return {"model": FABLE, "messages": messages or [{"role": "user", "content": "Inspect inputs."}],
            "max_tokens": 8192, "reasoning": {"effort": "medium"}}


def native(parts, stop="end_turn", model="claude-fable-5-1"):
    return {"id": "msg_fixture", "model": model, "stop_reason": stop,
            "content": parts, "usage": {"input_tokens": 10, "cache_read_input_tokens": 20,
                                      "cache_creation_input_tokens": 30, "output_tokens": 40}}


def client_for(response):
    client = object.__new__(AnthropicTransport)
    client.history = {}
    client.client = SimpleNamespace(invoke_model=lambda **kwargs: {
        "body": io.BytesIO(json.dumps(response).encode())})
    return client


def test_signed_multiple_tool_history_is_preserved_without_exposing_thinking_in_content():
    blocks = [
        {"type": "thinking", "thinking": "private fixture", "signature": "signed_fixture"},
        {"type": "tool_use", "id": "one", "name": "inspect", "input": {"path": "a"}},
        {"type": "tool_use", "id": "two", "name": "inspect", "input": {"path": "b"}},
    ]
    client = client_for(native(blocks, "tool_use"))
    result = client.complete(payload())
    assistant = result["choices"][0]["message"]
    assert assistant["content"] is None
    next_request = client.request(payload([
        {"role": "user", "content": "Inspect inputs."}, assistant,
        {"role": "tool", "tool_call_id": "one", "content": "a exists"},
        {"role": "tool", "tool_call_id": "two", "content": "b exists"},
    ]))
    assert next_request["messages"][1]["content"] == blocks
    assert len(next_request["messages"][2]["content"]) == 2
    assert result["usage"]["prompt_tokens"] == 60
    assert result["usage"]["completion_tokens"] == 40
    assistant["tool_calls"][0]["function"]["arguments"] = '{"path":"changed"}'
    with pytest.raises(ValueError, match="modified"):
        client.request(payload([{"role": "user", "content": "Inspect"}, assistant]))


def test_unknown_or_missing_tool_history_cannot_be_reconstructed_lossily():
    client = client_for(native([]))
    message = {"role": "assistant", "tool_calls": [
        {"id": "missing", "function": {"name": "x", "arguments": "{}"}}]}
    with pytest.raises(ValueError, match="signed tool history"):
        client.request(payload([message]))


def test_wrong_model_and_effort_are_rejected():
    client = client_for(native([], model="different-model"))
    with pytest.raises(RuntimeError, match="different Fable"):
        client.complete(payload())
    request = payload()
    request["reasoning"]["effort"] = "high"
    with pytest.raises(ValueError, match="model/effort"):
        client.request(request)


def test_researcher_uses_unchanged_schema_without_forced_tools():
    schema = {"type": "object", "properties": {"answer": {"type": "string"}},
              "required": ["answer"], "additionalProperties": False}
    response = native([{"type": "text", "text": '{"answer":"ready"}'}])
    transport = client_for(response)
    saved = []
    old_complete = transport.complete
    transport.complete = lambda request: (saved.append(copy.deepcopy(request)), old_complete(request))[1]
    with patch("personasciencebench.bedrock_transport.transport", return_value=transport):
        client = OpenRouterClient(FABLE, role="researcher", provider="bedrock", reasoning_effort="medium")
        assert client.complete_decision([{"role": "user", "content": "Ready?"}], schema) == '{"answer":"ready"}'
    request = transport.request(saved[0])
    assert request["output_config"]["format"]["schema"] == schema
    assert "tools" not in request and "tool_choice" not in request
    assert client.format_adaptations[0]["schema_unchanged"]


def test_incomplete_response_is_logged_and_rejected_not_retried():
    transport = client_for(native([{"type": "text", "text": "partial"}], "max_tokens"))
    logged = []
    with patch("personasciencebench.bedrock_transport.transport", return_value=transport):
        client = OpenRouterClient(FABLE, role="actor", provider="bedrock", reasoning_effort="medium",
                                  record=logged.append)
        with pytest.raises(RuntimeError, match="incomplete completion"):
            client.completion([{"role": "user", "content": "Ready?"}])
    assert len(logged) == 1
    assert logged[0]["response"]["_native_response"]["stop_reason"] == "max_tokens"


def test_invalid_decision_is_preserved_before_schema_validation():
    from jsonschema import ValidationError
    transport = client_for(native([{"type": "text", "text": '{"wrong":true}'}]))
    logged = []
    with patch("personasciencebench.bedrock_transport.transport", return_value=transport):
        client = OpenRouterClient(FABLE, role="researcher", provider="bedrock",
                                  reasoning_effort="medium", record=logged.append)
        with pytest.raises(ValidationError):
            client.complete_decision([{"role": "user", "content": "Ready?"}],
                                     {"type": "object", "required": ["answer"]})
    assert len(logged) == 1
    assert logged[0]["response"]["_native_response"]["content"][0]["text"] == '{"wrong":true}'


def unpriced():
    return ModelSettings(provider="bedrock", model=FABLE, reasoning_effort="medium",
                         max_output_tokens=8192, input_usd_per_million=None, output_usd_per_million=None)


def test_unknown_price_remains_null_and_cannot_bypass_dollar_cap(tmp_path):
    response = {"choices": [{"finish_reason": "stop", "message": {"content": "yes"}}],
                "usage": {"prompt_tokens": 12, "completion_tokens": 34}}
    transport = SimpleNamespace(mock=False, complete=lambda role, request: response)
    ledger = Ledger(Budget(None), Budget(None))
    gateway = Gateway(transport, {"researcher": unpriced()}, ledger, tmp_path / "calls.jsonl")
    gateway.complete("researcher", [{"role": "user", "content": "Ready?"}])
    assert ledger.summary()["budget_charge_usd"] is None
    assert ledger.records[0]["estimated_uncached_usd"] is None
    assert ledger.records[0]["billing_status"] == "unknown_price"
    assert ledger.records[0]["usage"]["completion_tokens"] == 34
    gateway = Gateway(transport, {"researcher": unpriced()}, Ledger(Budget(1), Budget(None)),
                      tmp_path / "bounded.jsonl")
    with pytest.raises(ModelError, match="verified prices"):
        gateway.complete("researcher", [])
    assert not (tmp_path / "bounded.jsonl").exists()


def test_exp_actor_sdk_accepts_unpriced_gateway_usage():
    from expbench.actor import GatewayLLM
    from openhands.sdk import Message, TextContent
    response = {"id": "offline-fixture", "object": "chat.completion", "model": "claude-fable-5-1",
                "choices": [{"index": 0, "finish_reason": "stop",
                             "message": {"role": "assistant", "content": "ready"}}],
                "usage": {"prompt_tokens": 12, "completion_tokens": 5, "total_tokens": 17}}
    gateway = SimpleNamespace(complete=lambda *args, **kwargs: response,
                              ledger=SimpleNamespace(records=[{"budget_charge_usd": None}]))
    episode = SimpleNamespace(design=None, actor_calls=0, gateway=gateway)
    llm = GatewayLLM(model="openrouter/" + FABLE, usage_id="offline-check",
                     max_input_tokens=100000, max_output_tokens=12288, log_completions=False)
    llm._episode = episode
    llm.completion([Message(role="user", content=[TextContent(text="Ready?")])])
    assert episode.actor_calls == 1
    assert gateway.ledger.records[-1]["budget_charge_usd"] is None


def test_machine_policy_checks_without_executing_prohibited_commands():
    for text in ("node app.js", "python -m http.server", "import socket", "ssh rlscience"):
        with pytest.raises(ValueError):
            validate_command(text)
    validate_command("python - <<'PY'\nfor node in range(5): print(node)\nPY")
